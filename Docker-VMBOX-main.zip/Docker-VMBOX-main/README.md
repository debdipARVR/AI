# Docker-VMBOX

Copy the python file 
install the modules 

ie 
pip install streamlit 
pip install pandas
pip install sqlite

run the file from app.py
